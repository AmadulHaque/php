<?php

namespace App;

class Calculator
{
    public static function calculate()
    {
        echo 10 + 10;
    }
}
