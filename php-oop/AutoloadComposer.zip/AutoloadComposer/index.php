<?php

require 'vendor/autoload.php' ;


use App\Classes\Car;
use App\Classes\Bike;




$car = new Car();
$bike = new Bike();


calculate();