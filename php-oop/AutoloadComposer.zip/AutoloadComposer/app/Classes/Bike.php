<?php

namespace App\Classes;

class Bike 
{
	
	function __construct()
	{
		echo "New Bike Create\n";
	}
}