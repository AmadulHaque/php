<?php

namespace App\Classes;

class Car 
{
	
	function __construct()
	{
		echo "New Car Create\n";
	}
}